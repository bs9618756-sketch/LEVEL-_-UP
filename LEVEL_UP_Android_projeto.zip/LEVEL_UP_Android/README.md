# LEVEL UP — Minha Evolução (Android)

Projeto Android que abre a experiência LEVEL UP em uma WebView local, sem depender do Chrome. O HTML está em `app/src/main/assets/index.html` e usa armazenamento local do WebView para manter o progresso neste aparelho.

## Gerar o APK pelo GitHub usando o celular
1. Entre no GitHub e crie um repositório novo chamado `LEVEL-UP` (público ou privado).
2. Envie os arquivos desta pasta para a raiz do repositório, mantendo as pastas.
3. Abra a aba **Actions** e selecione **Build LEVEL UP APK**.
4. Toque em **Run workflow** e aguarde o processo ficar verde.
5. Abra a execução concluída, desça até **Artifacts** e baixe `LEVEL-UP-debug-apk`. Extraia o ZIP para obter `app-debug.apk`.
6. Abra o APK no Android e autorize a instalação desta fonte, se solicitado.

O workflow compila com Java 17, Gradle 8.9 e Android SDK 35.

## Observações
- O app agenda um lembrete diário aproximado às 19h. O Android pode ajustar o horário por economia de bateria.
- O sistema solicita permissão de notificações no Android 13 ou superior.
- O progresso fica no armazenamento privado do aplicativo. Desinstalar o app ou limpar seus dados pode apagar o progresso; exportação/backup ainda não está implementada.
- Este é o projeto-fonte, não um APK já compilado.
